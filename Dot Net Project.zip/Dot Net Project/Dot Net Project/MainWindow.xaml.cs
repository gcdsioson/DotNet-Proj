﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Dot_Net_Project
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.Panel2.Visibility = System.Windows.Visibility.Collapsed;
            this.ForgotPass.Visibility = System.Windows.Visibility.Collapsed;
            this.Back.Visibility = System.Windows.Visibility.Collapsed;
            this.Login.Visibility = System.Windows.Visibility.Collapsed;
            
        }

        private void Next_Click(object sender, RoutedEventArgs e)
        {
          //  string x = 
            if (Panel1.Visibility == System.Windows.Visibility.Visible)
            {
                this.Panel1.Visibility = System.Windows.Visibility.Collapsed;
                this.Panel2.Visibility = System.Windows.Visibility.Visible;
                this.CreateAcc.Visibility = System.Windows.Visibility.Collapsed;
                this.ForgotPass.Visibility = System.Windows.Visibility.Visible;
                this.Back.Visibility = System.Windows.Visibility.Visible;
                this.Next.Visibility = System.Windows.Visibility.Collapsed;
                this.Login.Visibility = System.Windows.Visibility.Visible;
            }
   
            
        }

        private void Login_Click (object sender, RoutedEventArgs e)
        {
            //goes to user main window
            UserMainWindow win1 = new UserMainWindow();
            win1.Show();
            this.Close();

        }
        private void ForgotPass_Click(object sender, RoutedEventArgs e)
        {
            ForgotPass win2 = new ForgotPass();
            win2.Show();
            this.Close();
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            this.Panel1.Visibility = System.Windows.Visibility.Visible;
            this.Panel2.Visibility = System.Windows.Visibility.Collapsed;
            this.CreateAcc.Visibility = System.Windows.Visibility.Visible;
            this.ForgotPass.Visibility = System.Windows.Visibility.Collapsed;
            this.Back.Visibility = System.Windows.Visibility.Collapsed;
            this.Login.Visibility = System.Windows.Visibility.Collapsed;
            this.Next.Visibility = System.Windows.Visibility.Visible;
        }
    }
}
