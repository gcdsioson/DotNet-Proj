﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Net.Mail;

namespace Dot_Net_Project
{
    /// <summary>
    /// Interaction logic for ForgotPass.xaml
    /// </summary>
    public partial class ForgotPass : Window
    {
        public ForgotPass()
        {
            InitializeComponent();
        }

        public string password_generate()
        {
            //char limit 10
            char[] letters = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();
            Random rand = new Random();
            string word = "";
            for (int counter = 1; counter <= 10; counter++)
            {
                int series = rand.Next(0, letters.Length - 1);
                word += letters[series];
            }
        
                return word;

        }

        public void send_mail(string email)
        {
            //server yahoo , smpt add = smtp.mail.yahoo.com port 587 ssl yes
            //server Gmail , smpt add = smtp.gmail.com port 587 ssl yes
            // server Hotmail , smpt add = smtp.live.com port 587 ssl yes
            MailMessage mail = new MailMessage();
            SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");

            mail.From = new MailAddress("dingdongbot69@gmail.com");
            mail.To.Add(email);
            mail.Subject = "Request for Password Recovery";
            mail.Body = "This is for recovering your password.\n Your New password is "+ password_generate();

            SmtpServer.Port = 587;
            SmtpServer.Credentials = new System.Net.NetworkCredential("dingdongbot69@gmail.com", "glenn3.141592654");
            SmtpServer.EnableSsl = true;

            SmtpServer.Send(mail);
            MessageBox.Show("mail Send");
        }

        private void Recover_Click(object sender, RoutedEventArgs e)
        {
            string email= recover_email.Text;
            send_mail(email);
        }
}
    }

